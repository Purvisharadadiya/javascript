let arr = [
    {
        id: 1,
        name: "ELRINZA Air Sofa",
        qty: 1,
        price: 84,
        image: "https://i.pinimg.com/736x/5d/39/be/5d39be8121f5899b90aa0b794ede457e.jpg"
    },
    {
        id: 2,
        name: "Manual ",
        qty: 1,
        price: 80,
        image: "https://i.pinimg.com/736x/23/56/35/2356351866e91a6d0f99a4b0247603c5.jpg"
    },
    {
        id: 3,
        name: "purvisha",
        qty: 1,
        price: 100,
        image: "https://i.pinimg.com/474x/80/78/ca/8078ca891088ba8c23b171638a49ad3d.jpg"

    },
    {
        id: 4,
        name: " Recliner",
        qty: 1,
        price: 70,
        image: "https://i.pinimg.com/736x/56/e1/e2/56e1e2d23a14971ba507bf7b3b087c7a.jpg"
    },
    {
        id: 5,
        name: " Recliner",
        qty: 1,
        price: 70,
        image: "https://i.pinimg.com/736x/ee/61/ce/ee61ce8d83dfc36d93b04f3c4e290816.jpg"
    },
    {
        id: 6,
        name: " Recliner",
        qty: 1,
        price: 70,
        image: "https://i.pinimg.com/736x/4a/bb/84/4abb84e74090cbd903764c983f474d34.jpg"
    },
];



