let user = JSON.parse(localStorage.getItem('user'));

if (!user) {
    window.location.href = "index.html";
}